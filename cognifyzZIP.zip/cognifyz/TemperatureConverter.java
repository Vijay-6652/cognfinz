import java.util.*;

public class TemperatureConverter {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter temperature value: ");
        double temp = sc.nextDouble();
        System.out.print("Enter unit (C/F): ");
        String unit = sc.next().toUpperCase();
        double result;
        if(unit.equals("C")) {
            result = (temp * 9/5) + 32;
            System.out.println("Temperature in Fahrenheit: " + result);
        } else if(unit.equals("F")) {
            result = (temp - 32) * 5/9;
            System.out.println("Temperature in Celsius: " + result);
        } else {
            System.out.println("Invalid unit");
        }
    }
}
