import java.util.*;

public class PalindromeChecker {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a word or phrase: ");
        String text = sc.nextLine();
        text = text.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
        String rev = new StringBuilder(text).reverse().toString();
        if(text.equals(rev)) System.out.println("It is a palindrome");
        else System.out.println("It is not a palindrome");
    }
}
