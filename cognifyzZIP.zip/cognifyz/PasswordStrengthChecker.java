import java.util.*;

public class PasswordStrengthChecker {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter password: ");
        String pass = sc.nextLine();
        int score = 0;
        if (pass.length() >= 8) score++;
        if (pass.matches(".*[a-z].*")) score++;
        if (pass.matches(".*[A-Z].*")) score++;
        if (pass.matches(".*\d.*")) score++;
        if (pass.matches(".*[!@#$%^&*()_+\-={}\[\]:;"'<>,.?/].*")) score++;
        if (score <= 2) System.out.println("Weak password");
        else if (score == 3 || score == 4) System.out.println("Moderate password");
        else System.out.println("Strong password");
    }
}
