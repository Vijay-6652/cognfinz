import java.io.*;

public class FileEncryptDecrypt {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter file path: ");
        String path = sc.nextLine();
        System.out.print("Encrypt or Decrypt (e/d): ");
        char choice = sc.next().toLowerCase().charAt(0);
        System.out.print("Enter key (number): ");
        int key = sc.nextInt();
        try {
            FileInputStream in = new FileInputStream(path);
            byte[] data = in.readAllBytes();
            in.close();
            for (int i = 0; i < data.length; i++) data[i] = (byte) (data[i] + (choice == 'e' ? key : -key));
            String outPath = choice == 'e' ? "encrypted.txt" : "decrypted.txt";
            FileOutputStream out = new FileOutputStream(outPath);
            out.write(data);
            out.close();
            System.out.println("Output saved to " + outPath);
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}