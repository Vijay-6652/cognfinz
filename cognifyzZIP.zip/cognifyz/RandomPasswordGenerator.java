import java.util.*;

public class RandomPasswordGenerator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter password length: ");
        int len = sc.nextInt();
        System.out.print("Include numbers (y/n): ");
        boolean num = sc.next().equalsIgnoreCase("y");
        System.out.print("Include lowercase (y/n): ");
        boolean low = sc.next().equalsIgnoreCase("y");
        System.out.print("Include uppercase (y/n): ");
        boolean up = sc.next().equalsIgnoreCase("y");
        System.out.print("Include special characters (y/n): ");
        boolean spec = sc.next().equalsIgnoreCase("y");
        String chars = "";
        if(num) chars += "0123456789";
        if(low) chars += "abcdefghijklmnopqrstuvwxyz";
        if(up) chars += "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        if(spec) chars += "!@#$%^&*()-_=+<>?";
        if(chars.isEmpty()) {
            System.out.println("No character sets selected");
            return;
        }
        StringBuilder pass = new StringBuilder();
        Random r = new Random();
        for(int i = 0; i < len; i++) pass.append(chars.charAt(r.nextInt(chars.length())));
        System.out.println("Generated password: " + pass.toString());
    }
}
