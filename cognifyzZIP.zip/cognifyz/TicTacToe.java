import java.util.*;

public class TicTacToe {
    static char[][] board = new char[3][3];
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        boolean playAgain;
        do {
            resetBoard();
            char player = 'X';
            int moves = 0;
            while (true) {
                printBoard();
                System.out.print("Player " + player + ", enter row and column (1-3): ");
                int r = sc.nextInt() - 1;
                int c = sc.nextInt() - 1;
                if (r < 0 || c < 0 || r > 2 || c > 2 || board[r][c] != ' ') {
                    System.out.println("Invalid move, try again");
                    continue;
                }
                board[r][c] = player;
                moves++;
                if (checkWin(player)) {
                    printBoard();
                    System.out.println("Player " + player + " wins!");
                    break;
                }
                if (moves == 9) {
                    printBoard();
                    System.out.println("It's a draw!");
                    break;
                }
                player = (player == 'X') ? 'O' : 'X';
            }
            System.out.print("Play again? (y/n): ");
            playAgain = sc.next().equalsIgnoreCase("y");
        } while (playAgain);
    }

    static void resetBoard() {
        for (int i = 0; i < 3; i++) Arrays.fill(board[i], ' ');
    }

    static void printBoard() {
        System.out.println("-------");
        for (int i = 0; i < 3; i++) {
            System.out.print("|");
            for (int j = 0; j < 3; j++) System.out.print(board[i][j] + "|");
            System.out.println();
            System.out.println("-------");
        }
    }

    static boolean checkWin(char p) {
        for (int i = 0; i < 3; i++)
            if ((board[i][0] == p && board[i][1] == p && board[i][2] == p) ||
                (board[0][i] == p && board[1][i] == p && board[2][i] == p))
                return true;
        return (board[0][0] == p && board[1][1] == p && board[2][2] == p) ||
               (board[0][2] == p && board[1][1] == p && board[2][0] == p);
    }
}

